/**
 * Created by JetBrains WebStorm.
 * User: Administrator
 * Date: 12-5-16
 * Time: 上午10:59
 * To change this template use File | Settings | File Templates.
 */
LogModel = require("./log");
LogModel.addLog(1001,{"a":"d"})
